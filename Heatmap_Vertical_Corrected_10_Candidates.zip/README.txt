HEATMAP DỌC CHO POWER BI

1. Đặt file create_heatmaps_vertical.py cùng thư mục với heatmap_events.csv.
2. Cài các thư viện nếu máy chưa có:
   pip install pandas numpy matplotlib scipy
3. Chạy:
   python create_heatmaps_vertical.py
4. Ảnh được tạo trong thư mục output_heatmaps_vertical_v2.

QUY ƯỚC TỌA ĐỘ
- X nguồn: chiều dài sân, từ phần sân nhà đến khung thành đối phương.
- Y nguồn: chiều ngang sân, từ cánh trái đến cánh phải theo hướng tấn công.
- PlotX = Y * 68 / 100.
- PlotY = X * 105 / 100.
- Tất cả ảnh hiển thị hướng tấn công lên trên.
- Nếu AttackDirection = Left, code xoay cả hai trục 180 độ.

PHẠM VI
- Từ 03/08/2025 đến hết 19/07/2026.
- Code chấp nhận EventType = Touch hoặc ProviderHeatmapPoint.

LƯU Ý DỮ LIỆU HIỆN TẠI
CSV dùng để tạo bộ ảnh mẫu chỉ chứa các trận gần đây mà heatmap đã được thu thập,
không phải toàn bộ mọi trận trong kỳ xét. Dòng cuối mỗi ảnh ghi số địa điểm chạm bóng
và số trận thực tế có dữ liệu heatmap để tránh hiểu nhầm về phạm vi bao phủ.
