from pathlib import Path
import re
import unicodedata
import warnings

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.patches import Arc, Circle, Rectangle
from scipy.ndimage import gaussian_filter


# Ballon d'Or evaluation period agreed for this project.
START_DATE = pd.Timestamp("2025-08-03")
END_DATE = pd.Timestamp("2026-07-19")

CANDIDATES = {
    "P001": "Lamine Yamal",
    "P002": "Kylian Mbappé",
    "P003": "Rodri",
    "P004": "Lionel Messi",
    "P005": "Erling Haaland",
    "P006": "Harry Kane",
    "P007": "Vinícius Júnior",
    "P008": "Vitinha",
    "P009": "Fabián Ruiz",
    "P010": "Ferran Torres",
}

INPUT_FILE = Path("heatmap_events.csv")
OUTPUT_FOLDER = Path("output_heatmaps_vertical_v2")

# The existing FotMob SVG-derived file uses:
# X = longitudinal coordinate (own goal -> opponent goal), 0..100
# Y = lateral coordinate (left flank -> right flank), 0..100
# The player heatmaps retrieved for this project are already oriented toward +X.
FOTMOB_POINTS_ALREADY_ATTACK_POSITIVE_X = True

PITCH_LENGTH = 105.0
PITCH_WIDTH = 68.0
PITCH_GREEN = "#2C9C62"
PITCH_GREEN_ALT = "#28935B"
LINE_WHITE = "#FFFFFF"
TEXT_WHITE = "#F7FBF9"
SUBTEXT = "#D8EEE3"

HEAT_CMAP = LinearSegmentedColormap.from_list(
    "football_heat",
    ["#20C997", "#F5E642", "#FFB000", "#F0442E", "#9E0612"],
    N=256,
)


def safe_name(text):
    ascii_text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("ascii")
    return re.sub(r"[^a-z0-9]+", "_", ascii_text.lower()).strip("_")


def add_pitch_stripes(ax):
    stripe_height = PITCH_LENGTH / 10
    for index in range(10):
        color = PITCH_GREEN if index % 2 == 0 else PITCH_GREEN_ALT
        ax.add_patch(
            Rectangle(
                (0, index * stripe_height),
                PITCH_WIDTH,
                stripe_height,
                facecolor=color,
                edgecolor="none",
                zorder=0,
            )
        )


def draw_pitch(ax):
    """Draw a regulation-proportion vertical pitch; attack is toward the top."""
    ax.set_facecolor(PITCH_GREEN)
    add_pitch_stripes(ax)

    line = dict(fill=False, edgecolor=LINE_WHITE, linewidth=1.65, zorder=10)
    thin_line = dict(fill=False, edgecolor=LINE_WHITE, linewidth=1.35, zorder=10)

    # Outer boundary and halfway line.
    ax.add_patch(Rectangle((0, 0), PITCH_WIDTH, PITCH_LENGTH, **line))
    ax.plot([0, PITCH_WIDTH], [PITCH_LENGTH / 2, PITCH_LENGTH / 2],
            color=LINE_WHITE, linewidth=1.65, zorder=10)

    # Centre circle and centre mark.
    ax.add_patch(Circle((PITCH_WIDTH / 2, PITCH_LENGTH / 2), 9.15, **thin_line))
    ax.add_patch(Circle((PITCH_WIDTH / 2, PITCH_LENGTH / 2), 0.22,
                        facecolor=LINE_WHITE, edgecolor="none", zorder=10))

    penalty_width = 40.32
    goal_area_width = 18.32
    penalty_x = (PITCH_WIDTH - penalty_width) / 2
    goal_area_x = (PITCH_WIDTH - goal_area_width) / 2

    # Penalty areas.
    ax.add_patch(Rectangle((penalty_x, 0), penalty_width, 16.5, **thin_line))
    ax.add_patch(Rectangle((penalty_x, PITCH_LENGTH - 16.5),
                           penalty_width, 16.5, **thin_line))

    # Six-yard boxes.
    ax.add_patch(Rectangle((goal_area_x, 0), goal_area_width, 5.5, **thin_line))
    ax.add_patch(Rectangle((goal_area_x, PITCH_LENGTH - 5.5),
                           goal_area_width, 5.5, **thin_line))

    # Penalty spots and arcs.
    ax.add_patch(Circle((PITCH_WIDTH / 2, 11), 0.22,
                        facecolor=LINE_WHITE, edgecolor="none", zorder=10))
    ax.add_patch(Circle((PITCH_WIDTH / 2, PITCH_LENGTH - 11), 0.22,
                        facecolor=LINE_WHITE, edgecolor="none", zorder=10))
    ax.add_patch(Arc((PITCH_WIDTH / 2, 11), 18.3, 18.3,
                     theta1=37, theta2=143, color=LINE_WHITE,
                     linewidth=1.35, zorder=10))
    ax.add_patch(Arc((PITCH_WIDTH / 2, PITCH_LENGTH - 11), 18.3, 18.3,
                     theta1=217, theta2=323, color=LINE_WHITE,
                     linewidth=1.35, zorder=10))

    # Goals.
    goal_width = 7.32
    goal_x = (PITCH_WIDTH - goal_width) / 2
    ax.add_patch(Rectangle((goal_x, -2.0), goal_width, 2.0, **thin_line))
    ax.add_patch(Rectangle((goal_x, PITCH_LENGTH), goal_width, 2.0, **thin_line))

    # Corner arcs.
    corners = [
        ((0, 0), 0, 90),
        ((PITCH_WIDTH, 0), 90, 180),
        ((0, PITCH_LENGTH), 270, 360),
        ((PITCH_WIDTH, PITCH_LENGTH), 180, 270),
    ]
    for centre, theta1, theta2 in corners:
        ax.add_patch(Arc(centre, 2.0, 2.0, theta1=theta1, theta2=theta2,
                         color=LINE_WHITE, linewidth=1.2, zorder=10))

    ax.set_xlim(-2.5, PITCH_WIDTH + 2.5)
    ax.set_ylim(-3.0, PITCH_LENGTH + 3.0)
    ax.set_aspect("equal")
    ax.axis("off")


def standardize_coordinates(df):
    """
    Standardize every observation so the player attacks upward on a vertical pitch.

    Input schema:
      X = pitch length, 0..100
      Y = pitch width, 0..100

    If a row explicitly says the player attacks left, rotate the point 180 degrees.
    A 180-degree rotation changes BOTH axes; changing only X swaps the wings.
    """
    frame = df.copy()
    frame["Longitudinal"] = pd.to_numeric(frame["X"], errors="coerce")
    frame["Lateral"] = pd.to_numeric(frame["Y"], errors="coerce")

    if "AttackDirection" in frame.columns:
        direction = frame["AttackDirection"].astype(str).str.strip().str.lower()
        left_mask = direction.eq("left")
        frame.loc[left_mask, "Longitudinal"] = 100 - frame.loc[left_mask, "Longitudinal"]
        frame.loc[left_mask, "Lateral"] = 100 - frame.loc[left_mask, "Lateral"]

        unknown_mask = ~direction.isin(["left", "right"])
        if unknown_mask.any() and not FOTMOB_POINTS_ALREADY_ATTACK_POSITIVE_X:
            warnings.warn(
                "Some rows have no verified attack direction. Do not combine them "
                "until a match-level direction is supplied."
            )

    # Rotate the data representation into a vertical tactical board:
    # lateral position -> screen X; longitudinal position -> screen Y.
    frame["PlotX"] = frame["Lateral"] * PITCH_WIDTH / 100
    frame["PlotY"] = frame["Longitudinal"] * PITCH_LENGTH / 100
    return frame


def density_layer(player_events):
    x = player_events["PlotX"].to_numpy()
    y = player_events["PlotY"].to_numpy()

    heat, _, _ = np.histogram2d(
        x,
        y,
        bins=(68, 105),
        range=[[0, PITCH_WIDTH], [0, PITCH_LENGTH]],
    )
    heat = gaussian_filter(heat.T, sigma=3.1)

    maximum = heat.max()
    if maximum <= 0:
        return heat, np.zeros_like(heat)

    normalized = heat / maximum

    # Suppress the weak all-pitch haze and keep the useful hot zones visible.
    alpha = np.clip((normalized - 0.035) / 0.965, 0, 1) ** 0.58
    alpha *= 0.94
    return normalized, alpha


def create_heatmap(player_id, player_name, player_events):
    if player_events.empty:
        print(f"No valid coordinate data: {player_name}")
        return None

    heat, alpha = density_layer(player_events)
    match_column = "MatchID" if "MatchID" in player_events.columns else "ProviderMatchID"
    matches = player_events[match_column].nunique() if match_column in player_events.columns else 0

    fig, ax = plt.subplots(figsize=(5.4, 8.5), facecolor="#164E36")
    fig.subplots_adjust(left=0.065, right=0.935, bottom=0.085, top=0.845)
    draw_pitch(ax)

    ax.imshow(
        heat,
        origin="lower",
        extent=[0, PITCH_WIDTH, 0, PITCH_LENGTH],
        cmap=HEAT_CMAP,
        alpha=alpha,
        interpolation="bicubic",
        vmin=0,
        vmax=1,
        zorder=5,
    )

    # Draw the white pitch markings again so they remain crisp above the heat layer.
    draw_pitch(ax)

    title_size = 18 if len(player_name) <= 15 else 15.5
    fig.suptitle(
        player_name,
        color=TEXT_WHITE,
        fontsize=title_size,
        fontweight="bold",
        y=0.966,
    )
    fig.text(
        0.5,
        0.918,
        "Touch Heatmap | 03 Aug 2025 – 19 Jul 2026",
        color=SUBTEXT,
        fontsize=9.5,
        ha="center",
    )
    fig.text(
        0.5,
        0.893,
        "Attack direction ↑ | Right wing = right side of image",
        color=SUBTEXT,
        fontsize=8.2,
        ha="center",
    )
    fig.text(
        0.5,
        0.025,
        f"{len(player_events):,} locations | {matches} matches with available heatmap data",
        color=SUBTEXT,
        fontsize=8.5,
        ha="center",
    )

    OUTPUT_FOLDER.mkdir(parents=True, exist_ok=True)
    output_file = OUTPUT_FOLDER / f"{player_id}_{safe_name(player_name)}_heatmap_vertical.png"
    fig.savefig(output_file, dpi=240, bbox_inches="tight", pad_inches=0.08,
                facecolor=fig.get_facecolor())
    plt.close(fig)
    print(
        f"Created: {output_file} | median screen side="
        f"{player_events['PlotX'].median():.1f}/{PITCH_WIDTH:.0f}"
    )
    return output_file


def main():
    df = pd.read_csv(INPUT_FILE)
    required = {"PlayerID", "EventDate", "X", "Y"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError("Missing columns: " + ", ".join(sorted(missing)))

    df["EventDate"] = pd.to_datetime(df["EventDate"], errors="coerce")
    df["X"] = pd.to_numeric(df["X"], errors="coerce")
    df["Y"] = pd.to_numeric(df["Y"], errors="coerce")

    df = df[
        df["EventDate"].between(START_DATE, END_DATE, inclusive="both")
        & df["PlayerID"].isin(CANDIDATES)
        & df["X"].between(0, 100)
        & df["Y"].between(0, 100)
    ].copy()

    # Accept both a manually-labelled Touch row and FotMob's provider heatmap points.
    if "EventType" in df.columns:
        allowed_types = {"touch", "providerheatmappoint"}
        df = df[
            df["EventType"].astype(str).str.replace(" ", "", regex=False).str.lower().isin(allowed_types)
        ].copy()

    df = standardize_coordinates(df)

    for player_id, player_name in CANDIDATES.items():
        create_heatmap(
            player_id,
            player_name,
            df[df["PlayerID"] == player_id].copy(),
        )

    # Dataset-specific orientation check: Yamal should be on the right and Vinícius on the left.
    checks = {
        "P001": ("right", lambda value: value > PITCH_WIDTH / 2),
        "P007": ("left", lambda value: value < PITCH_WIDTH / 2),
    }
    for player_id, (expected, predicate) in checks.items():
        median_x = df.loc[df["PlayerID"] == player_id, "PlotX"].median()
        if pd.notna(median_x) and not predicate(median_x):
            warnings.warn(
                f"Orientation check failed for {player_id}: expected {expected} side, "
                f"median PlotX={median_x:.1f}. Check the source coordinate convention."
            )


if __name__ == "__main__":
    main()
